
document.getElementById("lang-switch").addEventListener("click", function() {
    let elements = document.querySelectorAll("[data-lang]");
    let lang = document.documentElement.lang === "ar" ? "en" : "ar";

    let translations = {
        "home": { "ar": "الرئيسية", "en": "Home" },
        "about": { "ar": "من نحن", "en": "About Us" },
        "services": { "ar": "الخدمات", "en": "Services" },
        "contact": { "ar": "اتصل بنا", "en": "Contact Us" },
        "welcome": { "ar": "مرحبًا بكم في elfrgany", "en": "Welcome to elfrgany" },
        "desc": { "ar": "نحن نقدم أفضل الخدمات بأعلى جودة.", "en": "We provide top-quality services." },
        "contact-btn": { "ar": "تواصل معنا", "en": "Contact Us" }
    };

    elements.forEach(el => {
        let key = el.getAttribute("data-lang");
        if (translations[key]) {
            el.textContent = translations[key][lang];
        }
    });

    document.getElementById("lang-switch").textContent = lang === "ar" ? "EN" : "عربي";
    document.documentElement.lang = lang;
});
